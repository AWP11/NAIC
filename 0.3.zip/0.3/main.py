import random
import numpy as np
import sqlite3

# Database setup
DB_NAME = "ai_memory.db"
conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

# Create the database table if it doesn't exist
cursor.execute("""
    CREATE TABLE IF NOT EXISTS datasets (
        name TEXT PRIMARY KEY,
        words TEXT
    )
""")
conn.commit()

class AI:
    def __init__(self):
        # Initialize input and output dictionaries
        self.input_layer = {}
        self.output_layer = {}
        # Generate a random value for later
        self.legingIO = random.randint(0, 50)
        self.set_unhow_variathion = {}  # Initialize the dictionary for unhow variathion

    def generate_data(self, input_text):
        # Split the input text into words
        words = input_text.split()
        # Store the words in the input layer
        self.input_layer = {i: word for i, word in enumerate(words)}

        # Generate output based on global memory
        self.output_layer = AI.IO_generate(self.input_layer)

        # Add new words to global memory (with limit)
        self.reading_and_recording("shortest_words", words[:10])  # Limit to 10 words
        self.reading_and_recording("longest_words", words[:10])  # Limit to 10 words

        # Update unhow variathion set
        self.update_unhow_variathion(input_text)

    @staticmethod
    def reading_and_recording(record_data, read_data):
        # Record data to global memory
        global conn, cursor
        # Create a new entry for each input (overwrites if exists)
        words_string = " ".join(read_data)
        cursor.execute("""
            INSERT OR REPLACE INTO datasets (name, words) 
            VALUES (?, ?)
        """, (record_data, words_string))
        conn.commit()

    @staticmethod
    def reading_from_memory(read_data):
        # Read data from global memory
        global conn, cursor
        cursor.execute("""
            SELECT words FROM datasets WHERE name = ?
        """, (read_data,))
        result = cursor.fetchone()
        if result:
            return result[0].split()  # Split the string into words
        else:
            return []

    @staticmethod
    def IO_generate(input_layer):
        # Generate output based on global memory
        output_layer = {}
        for i, word in input_layer.items():
            # Get all words from all datasets
            all_words = []
            cursor.execute("""
                SELECT words FROM datasets
            """)
            for row in cursor.fetchall():
                all_words.extend(row[0].split())

            # Check if the word is in the global memory
            if word in all_words:
                # Compare the sets
                shortest_words = set(AI.reading_from_memory("shortest_words"))
                longest_words = set(AI.reading_from_memory("longest_words"))
                common_elements = shortest_words & longest_words  # Intersection

                # Handle empty sets and division by zero
                if len(shortest_words) > 0:
                    similarity_ratio = len(common_elements) / len(shortest_words)
                else:
                    similarity_ratio = 0

                # Check for similar sets
                if similarity_ratio > 0.5:
                    # Sets are similar - create a single text
                    output_layer[i] = "These words are often used together: " + " ".join(all_words)
                else:
                    # Provide a consistent response when word is found
                    output_layer[i] = f"I've seen the word '{word}' before!"

            else:
                if all_words:
                    # Choose a random word if sets are not similar
                    output_layer[i] = np.random.choice(all_words)
                else:
                    output_layer[i] = "I haven't seen any words yet!"
        return output_layer

    @staticmethod
    def generative_ascii_value(text):
        """
        Generates ASCII values for a given text.
        """
        return [ord(char) for char in text]

    def unhow_variathion(self, text):
        """
        Implements unhow variathion using ASCII encoding and special patterns.
        """
        ascii_values = self.generative_ascii_value(text)

        # Create sets based on ASCII values
        shortest_words = []
        longest_words = []
        current_word = []
        for value in ascii_values:
            current_word.append(value)
            if value == ord(" "):
                # End of word
                if len(current_word) <= 5:
                    shortest_words.append(current_word)
                else:
                    longest_words.append(current_word)
                current_word = []

        # You can now use the 'shortest_words' and 'longest_words' lists
        # for further processing, including comparing them.
        # Example:
        print("Shortest words:", shortest_words)
        print("Longest words:", longest_words)

    def update_unhow_variathion(self, text):
        """
        Updates the unhow variathion set based on input text.
        """
        ascii_values = self.generative_ascii_value(text)

        # Create sets based on ASCII values
        shortest_words = []
        longest_words = []
        current_word = []
        for value in ascii_values:
            current_word.append(value)
            if value == ord(" "):
                # End of word
                if len(current_word) <= 5:
                    shortest_words.append(current_word)
                else:
                    longest_words.append(current_word)
                current_word = []

        # Calculate variations of context
        total_sets = len(AI.reading_from_memory("shortest_words")) + \
                    len(AI.reading_from_memory("longest_words"))
        variations_of_context = {}
        for word_set in shortest_words + longest_words:
            count = 0
            cursor.execute("""
                SELECT name FROM datasets
            """)
            for dataset_name in cursor.fetchall():
                dataset_name = dataset_name[0]
                if word_set in AI.reading_from_memory(dataset_name):
                    count += 1
            # Create dynamic dictionary for probability and weight
            variations_of_context[tuple(word_set)] = {"вероятность": total_sets * count / len(AI.reading_from_memory(dataset_name)), "вес": 1}

        # Update the unhow variathion set
        self.set_unhow_variathion = {
            "набор значений": [shortest_words, longest_words],
            "варинатов контекста": variations_of_context
        }

while True:
    # Get user input
    user_input = input("user>> ")

    # Create an instance of the AI class
    ai = AI()

    # Process the data
    ai.generate_data(user_input)

    # Generate the output response
    output_response = " ".join(ai.output_layer.values())  # Join the output layer values

    # Print the output response
    print(f"bot>> {output_response}")

# Close the database connection
conn.close()